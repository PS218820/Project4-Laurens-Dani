@extends('layouts.main')
@section('title')
    {{ __('Dashboard') }}
@endsection

@section('content')
    Je bent ingelogd
@endsection
