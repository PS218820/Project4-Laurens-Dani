// Geen create customer
// Dat gebeurt via de website en de auth/register.blade.php
