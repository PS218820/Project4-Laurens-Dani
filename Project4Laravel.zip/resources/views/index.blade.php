@extends('layouts.home')
@section('title')
    De beste pizza in Eindhoven.
@endsection
@section('undertitle')
    U bent van harte welkom om onze versgebakken pizza's in ons restaurant in Eindhoven te proeven!
@endsection
@section('button')
    Bekijk ons menu.
@endsection
@section('secondtitle')
    Wie zijn wij?
@endsection
@section('seconddescription')
    Wij zijn een pizza restaurant in hartje Eindhoven met een gezellige sfeer. Verse pizza staat op nummer 1 bij ons! Onze pizza mario komt oorspronkelijk uit italie
    en bakt zijn pizza's op de originele manier
@endsection
