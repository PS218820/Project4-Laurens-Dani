@extends('layouts.hometailwind')
@section('title')
    De beste pizza in Eindhoven.
@endsection
@section('description')
    U bent van harte welkom om onze versgebakken pizza's in ons restaurant in Eindhoven te proeven!
@endsection
