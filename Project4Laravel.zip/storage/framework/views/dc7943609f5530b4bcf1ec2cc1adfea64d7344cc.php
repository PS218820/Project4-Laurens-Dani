<?php $__env->startSection('title'); ?>
    De beste pizza in Eindhoven.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('undertitle'); ?>
    U bent van harte welkom om onze versgebakken pizza's in ons restaurant in Eindhoven te proeven!
<?php $__env->stopSection(); ?>
<?php $__env->startSection('button'); ?>
    Bekijk ons menu.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('secondtitle'); ?>
    Wie zijn wij?
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seconddescription'); ?>
    Wij zijn een pizza restaurant in hartje Eindhoven met een gezellige sfeer. Verse pizza staat op nummer 1 bij ons! Onze pizza mario komt oorspronkelijk uit italie
    en bakt zijn pizza's op de originele manier
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/index.blade.php ENDPATH**/ ?>