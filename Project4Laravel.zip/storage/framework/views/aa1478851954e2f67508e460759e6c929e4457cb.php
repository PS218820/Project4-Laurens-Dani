
<div class="container items-center">
    <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="grid grid-cols-1 md:grid-cols-6">
                <div><?php echo e($pizza->naam); ?></div>
                <div><?php echo e($pizza->prijs); ?></div>
                <div><?php echo e($pizza->ingredienten); ?></div>
              
                    <div class="inline-flex gap-1 mb-1">
                        <form action="<?php echo e(route('pizzas.details', [$pizza])); ?>" method="get">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-3 bg-blue-500 w-32']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-3 bg-blue-500 w-32']); ?>
                                <?php echo e(__('Details')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </form>

                        <a href="/pizzas/<?php echo e($pizza->id); ?>/samenstellen" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full">Update</a>



                    </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/pizzas/index.blade.php ENDPATH**/ ?>