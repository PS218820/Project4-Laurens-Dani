<?php $__env->startSection('title'); ?>
    Uw winkelwagen.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('undertitle'); ?>
    Hier staat alles wat u geslecteerd heeft!
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="my-8">
        <div class="container px-6 mx-auto">
            <div class="flex justify-center my-6">
                <div class="flex flex-col w-full p-8 text-gray-800 bg-white shadow-lg pin-r pin-y md:w-4/5 lg:w-4/5">
                    <div class="flex-1">
                        <table class="w-full text-sm lg:text-base" cellspacing="0">
                            <thead>
                            <tr class="h-12">
                                <th class="hidden md:table-cell"></th>
                                <th class="text-left">Pizza:</th>
                                <th class="pl-5 text-left lg:text-right lg:pl-0">
                                    <span class="lg:hidden" title="Quantity">Qtd</span>
                                    <span class="hidden lg:inline">Aantal:</span>
                                </th>
                                <th class="hidden text-right md:table-cell"> Prijs:</th>
                                <th class="hidden text-right md:table-cell"> Verwijderen: </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="hidden pb-4 md:table-cell">

                                    </td>
                                    <td>
                                        <a href="#">
                                            <p class="mb-2 md:ml-4"><?php echo e($item->name); ?></p>

                                        </a>
                                    </td>
                                    <td class="justify-center mt-6 md:justify-end md:flex">
                                        <div class="h-10 w-28">
                                            <div class="relative flex flex-row w-full h-8">

                                                <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>" >
                                                    <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>"
                                                           class="w-50 text-center bg-gray-300" />
                                                    <button type="submit" class="bg-black hover:bg-black-700 text-white font-bold py-0.5 px-0.4 rounded focus:outline-none focus:shadow-outline">update</button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="hidden text-right md:table-cell">
                                <span class="text-sm font-medium lg:text-base">
                                    €<?php echo e($item->price); ?>

                                </span>
                                    </td>
                                    <td class="hidden text-right md:table-cell">
                                        <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                            <button class="bg-black hover:bg-black-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Verwijder</button>
                                        </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                        <div>
                            Totaal: €<?php echo e(Cart::getTotal()); ?>

                        </div>
                        <div>
                            <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="bg-black hover:bg-black-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Verwijder alles uit de winkelwagen</button>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contenttailwind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/cart.blade.php ENDPATH**/ ?>