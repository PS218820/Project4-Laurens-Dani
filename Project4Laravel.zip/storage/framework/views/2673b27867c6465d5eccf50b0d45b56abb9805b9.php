<?php $__env->startSection('title'); ?>
    Hieronder kunt u onze heerlijke gerechten bestellen.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('undertitle'); ?>
    Kies er een paar uit!
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container px-6 mx-auto">
        <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md">
                    <div class="flex items-end justify-end w-full bg-cover">
                    </div>
                    <div class="px-5 py-3">
                        <h3 class="text-gray-700"><?php echo e($product->naam); ?></h3>
                        <p class="text-gray-500"><?php echo e($product->beschrijving); ?></p>
                        <p class="text-gray-500"><?php echo e($product->ingredienten); ?></p>
                        <span class="mt-2 text-gray-500">€<?php echo e($product->prijs); ?></span>

                        <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                            <input type="hidden" value="<?php echo e($product->naam); ?>" name="name">
                            <input type="hidden" value="<?php echo e($product->prijs); ?>" name="price">
                            <input type="hidden" value="1" name="quantity">
                            <button class="bg-black hover:bg-black-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Voeg toe</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contenttailwind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/products.blade.php ENDPATH**/ ?>