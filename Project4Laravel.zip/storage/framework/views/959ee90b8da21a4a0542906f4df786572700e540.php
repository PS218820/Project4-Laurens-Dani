<html>
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        body{
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>
<body>
<nav>
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a class="nav-link" aria-current="page" href="#">Menu</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Bestellen</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
        </li>
    </ul>
</nav>

<br><br><br><br>
        <h1 class="text-center">
            <?php echo $__env->yieldContent('title'); ?>
        </h1>
        <p class="text-center">
            <?php echo $__env->yieldContent('undertitle'); ?>
        </p>
<div class="row">
    <div class="col text-center">
        <button type="button" class="btn btn-primary"><?php echo $__env->yieldContent('button'); ?></button>
    </div>
</div>

<h3 class="text-center">
    <?php echo $__env->yieldContent('secondtitle'); ?>
</h3>
<p class="text-center w-1">
    <?php echo $__env->yieldContent('seconddescription'); ?>
</p>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
        integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
        integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
        crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/layouts/home.blade.php ENDPATH**/ ?>