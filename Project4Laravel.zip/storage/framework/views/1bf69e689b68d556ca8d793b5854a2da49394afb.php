<?php $__env->startSection('title'); ?>
    De beste pizza in Eindhoven.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
    U bent van harte welkom om onze versgebakken pizza's in ons restaurant in Eindhoven te proeven!
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.hometailwind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/Homepage.blade.php ENDPATH**/ ?>