<p>Details van de pizza:<br> 
<?php echo e($pizza->beschrijving); ?></p>
<br>
<p>Ingredienten op de pizza:<br> 
<?php echo e($pizza->ingredienten); ?></p><?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/pizzas/details.blade.php ENDPATH**/ ?>