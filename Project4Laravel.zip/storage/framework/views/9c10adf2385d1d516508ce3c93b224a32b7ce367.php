<?php $__env->startSection('title'); ?>
    Hieronder vind u ons menu.
<?php $__env->stopSection(); ?>
<?php $__env->startSection('undertitle'); ?>
    Wij maken alleen maar VERSE pizza's!
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Menu -->
    <section class="sectionSize bg-secondary justify-center md:justify-between md:items-center flex flex-col">
        <div class="md:grid md:grid-cols-5 md:grid-rows-3">
            <?php $__currentLoopData = $pizza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-start font-montserrat my-6 mr-10">
                    <div>
                        <h3 class="font-semibold text-2xl"><?php echo e($pizza->naam); ?></h3>
                        <p>
                            <?php echo e($pizza->beschrijving); ?> <br> <?php echo e($pizza->ingredienten); ?>

                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contenttailwind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lauko\Documents\School\SD2C\Project 4\Project4Laravel\resources\views/menu.blade.php ENDPATH**/ ?>